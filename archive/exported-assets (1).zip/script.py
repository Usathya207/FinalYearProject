# Create updated requirements.txt with compatible versions for Python 3.13
updated_requirements = """
# Core ML and AI packages
torch>=2.6.0
torchvision>=0.21.0
transformers>=4.40.0
sentence-transformers>=3.0.0
datasets>=2.20.0
accelerate>=0.30.0

# Reinforcement Learning
stable-baselines3>=2.3.0
gymnasium>=0.29.0

# Computer Vision and Image Processing  
Pillow>=10.0.0
opencv-python>=4.9.0.80

# Data Science
numpy>=1.24.0
pandas>=2.0.0
scikit-learn>=1.3.0
matplotlib>=3.7.0
seaborn>=0.12.0
plotly>=5.17.0

# Web Framework
streamlit>=1.35.0

# Utilities
requests>=2.31.0
python-dotenv>=1.0.0

# Optional: For better performance (uncomment if needed)
# torch-audio>=2.6.0  # For audio processing
# torchtext>=0.16.0   # For advanced NLP
"""

with open("requirements.txt", "w") as f:
    f.write(updated_requirements.strip())

print("✅ Updated requirements.txt with compatible versions for Python 3.13")

# Also create a lighter requirements file for basic functionality
basic_requirements = """
# Minimal requirements for basic functionality
torch>=2.6.0
transformers>=4.40.0
sentence-transformers>=3.0.0
stable-baselines3>=2.3.0
gymnasium>=0.29.0
streamlit>=1.35.0
Pillow>=10.0.0
numpy>=1.24.0
pandas>=2.0.0
requests>=2.31.0
plotly>=5.17.0
"""

with open("requirements_basic.txt", "w") as f:
    f.write(basic_requirements.strip())

print("✅ Created requirements_basic.txt for minimal installation")

print("\n🔧 Installation Options:")
print("1. Full installation: pip install -r requirements.txt")
print("2. Basic installation: pip install -r requirements_basic.txt")
print("3. Step-by-step installation (recommended):")
print("   pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu")
print("   pip install transformers sentence-transformers")
print("   pip install stable-baselines3 gymnasium")
print("   pip install streamlit plotly")
print("   pip install Pillow numpy pandas requests")